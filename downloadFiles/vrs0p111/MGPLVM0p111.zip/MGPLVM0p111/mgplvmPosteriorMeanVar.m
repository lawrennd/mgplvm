function [mu, varsigma, var_f, mean_F] = mgplvmPosteriorMeanVar(model, X);

% MGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
%
%	Description:
%
%	[MU, SIGMA] = MGPLVMPOSTERIORMEANVAR(MODEL, X) returns the posterior
%	mean and variance for a given set of points for the mixtures of
%	GP-LVM model.
%	 Returns:
%	  MU - the mean of the posterior distribution.
%	  SIGMA - the variances of the posterior distributions.
%	 Arguments:
%	  MODEL - the model for which the posterior will be computed.
%	  X - the input positions for which the posterior will be computed.
%	
%
%	See also
%	GPPOSTERIORMEANVAR, MGPLVMCREATE


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmPosteriorMeanVar.m CVS version 1.2
% 	mgplvmPosteriorMeanVar.m SVN version 355
% 	last update 2008-01-02T23:53:25.000000Z

if model.isGating 
  Xpi = mgplvmGatingProbabilities(model, X);
else
  Xpi = mgplvmComputeS(model, X);
end
[mean_F, var_F, secMo_F] = mgplvmComponentPosteriorMeanVar(model, X);

% Work out means and variances
mu = zeros(size(X, 1), model.d);
secMo = zeros(size(X, 1), model.d);
for m = 1:model.M
  mu = mu + mean_F{m}.*repmat(Xpi(:, m), 1, model.d);
  secMo = secMo + secMo_F{m}.*repmat(Xpi(:, m), 1, model.d);
end

varsigma = secMo - mu.*mu;

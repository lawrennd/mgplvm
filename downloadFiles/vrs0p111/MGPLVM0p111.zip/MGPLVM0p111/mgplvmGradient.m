function g = mgplvmGradient(params, model)

% MGPLVMGRADIENT Mixtures of GP-LVM gradient wrapper.
%
%	Description:
%
%	G = MGPLVMGRADIENT(PARAMS, MODEL) is a wrapper function for the
%	gradient of the negative log likelihood of an GP-LVM model with
%	respect to the latent postions and parameters.
%	 Returns:
%	  G - the gradient of the negative log likelihood with respect to
%	   the latent positions and the parameters at the given point.
%	 Arguments:
%	  PARAMS - vector of parameters and latent postions where the
%	   gradient is to be evaluated.
%	  MODEL - the model structure into which the latent positions and
%	   the parameters will be placed.
%	
%
%	See also
%	MGPLVMLOGLIKEGRADIENTS, MGPLVMEXPANDPARAM


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmGradient.m CVS version 1.1
% 	mgplvmGradient.m SVN version 355
% 	last update 2007-05-03T09:47:12.000000Z

model = mgplvmExpandParam(model, params);
g = - mgplvmLogLikeGradients(model);

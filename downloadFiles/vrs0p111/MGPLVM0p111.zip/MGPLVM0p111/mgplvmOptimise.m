function model = mgplvmOptimise(model, display, iters);

% MGPLVMOPTIMISE Optimise the mixtures of GP-LVM.
%
%	Description:
%
%	MODEL = MGPLVMOPTIMISE(MODEL, DISPLAY, ITERS) takes a given GP-LVM
%	model structure and optimises with respect to kernel parameters and
%	latent positions and gating centres.
%	 Returns:
%	  MODEL - the optimised model.
%	 Arguments:
%	  MODEL - the model to be optimised.
%	  DISPLAY - flag dictating whether or not to display optimisation
%	   progress (set to greater than zero) (default value 1).
%	  ITERS - number of iterations to run the optimiser for (default
%	   value 2000).
%	mgplvmLogLikeGradients, mgplvmObjective, mgplvmGradient
%	
%
%	See also
%	MGPLVMCREATE, MGPLVMLOGLIKELIHOOD, 


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmOptimise.m CVS version 1.1
% 	mgplvmOptimise.m SVN version 355
% 	last update 2007-05-22T23:18:05.000000Z

if nargin < 3
  iters = 2000;
  if nargin < 2
    display = 1;
  end
end


params = mgplvmExtractParam(model);

options = optOptions;
if display
  options(1) = 1;
  if length(params) <= 100
    options(9) = 1;
  end
end
options(14) = iters;

if isfield(model, 'optimiser')
  optim = str2func(model.optimiser);
else
  optim = str2func('scg');
end

if strcmp(func2str(optim), 'optimiMinimize')
  % Carl Rasmussen's minimize function 
  params = optim('mgplvmObjectiveGradient', params, options, model);
else
  % NETLAB style optimization.
  params = optim('mgplvmObjective', params,  options, ...
                 'mgplvmGradient', model);
end

model = mgplvmExpandParam(model, params);

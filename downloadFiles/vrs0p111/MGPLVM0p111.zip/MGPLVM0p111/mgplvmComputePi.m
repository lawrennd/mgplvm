function pim = mgplvmComputePi(model)

% MGPLVMCOMPUTEPI Compute the expectations of the component priors.
%
%	Description:
%
%	PI = MGPLVMCOMPUTEPI(MODEL) computes the expectations of the
%	component indicator matrix.
%	 Returns:
%	  PI - the expectations of the indicator matrix.
%	 Arguments:
%	  MODEL - the model for which expectations are to be updated.
%	
%	
%
%	See also
%	MGPLVMCREATE


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmComputePi.m SVN version 355
% 	last update 2008-01-02T23:52:35.000000Z
  
% Update expectations of pi.
if model.isInfinite
  % First compute expectations of v.
  sumS = sum(model.expectation.s);
  a0bar = model.a0 + sumS; % Posterior value for a_0.
  a1bar = model.a1 + cumsum(sumS); % Posterior value for a_1.
  model.v = a0bar./(a0bar+a1bar);
  tmp = cumprod(1-model.v);
  pim = model.v;
  pim(2:end) = pim(2:end).*tmp(1:end-1);
elseif model.isGating
  pim = mgplvmGatingProbabilities(model);
else
  pim = (sum(model.expectation.s, 1)+1)/(model.N+model.M);
end


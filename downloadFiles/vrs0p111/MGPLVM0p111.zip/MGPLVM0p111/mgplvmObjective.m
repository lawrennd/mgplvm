function f = mgplvmObjective(params, model)

% MGPLVMOBJECTIVE Wrapper function for mixtures of GP-LVM objective.
%
%	Description:
%
%	F = MGPLVMOBJECTIVE(PARAMS, MODEL) provides a wrapper function for
%	the GP-LVM, it takes the negative of the log likelihood, feeding the
%	parameters correctly to the model.
%	 Returns:
%	  F - the negative of the log likelihood of the model.
%	 Arguments:
%	  PARAMS - the parameters of the GP-LVM model.
%	  MODEL - the model structure in which the parameters are to be
%	   placed.
%	
%
%	See also
%	MGPLVMCREATE, MGPLVMLOGLIKELIHOOD, MGPLVMEXPANDPARAM


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmObjective.m CVS version 1.1
% 	mgplvmObjective.m SVN version 355
% 	last update 2007-05-03T09:47:20.000000Z

model = mgplvmExpandParam(model, params);
f = - mgplvmLogLikelihood(model);

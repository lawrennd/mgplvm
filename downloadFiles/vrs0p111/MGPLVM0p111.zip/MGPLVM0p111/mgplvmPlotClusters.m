function [] = mgplvmPlotClusters(model)

% MGPLVMPLOTCLUSTERS plots the cluster labels associated with the latent space.
%
%	Description:
%
%	MGPLVMPLOTCLUSTERS(MODEL) takes a model and plots the latent space
%	with symbols based on the most likely cluster label.
%	 Arguments:
%	  MODEL - the model for which the plot is to be prepared.
%	
%
%	See also
%	LVMTWODPLOT, LVMSCATTERPLOT


%	Copyright (c) 2007 Raquel Urtasun
% 	mgplvmPlotClusters.m CVS version 1.3
% 	mgplvmPlotClusters.m SVN version 355
% 	last update 2008-01-02T23:53:25.000000Z
  
% latent space.
% lbls of the cluster
[kk lbls_s] = max(model.expectation.s');
lbls = zeros(size(model.expectation.s));
for i=1:size(model.expectation.s,2)
  % for each class
  lbls(find(lbls_s==i),i) = 1;
end

switch model.q 
 case 1
  figure
  plot(1:model.N,model.X(:,1),'r.')
  hold on
  symbol = getSymbols(size(lbls,2));
  data = lvmTwoDPlot([[1:model.N]',model.X], lbls, symbol);
 case 2
  figure
  plot(model.X(:,1),model.X(:,2),'r.');
  hold on
  symbol = getSymbols(size(lbls,2));
  data = lvmTwoDPlot(model.X, lbls, symbol); 
 case 3
  figure
  plot3(model.X(:,1),model.X(:,2),model.X(:,3),'bo')
  hold on
  symbol = getSymbols(size(lbls,2));
  data = lvmThreeDPlot(model.X, lbls, symbol);
end

function [comp, noise, mgplvmInfo, X] = mgplvmDeconstruct(model)

% MGPLVMDECONSTRUCT break MGPLVM in pieces for saving.
%
%	Description:
%
%	[COMP, NOISE, MGPLVMINFO] = MGPLVMDECONSTRUCT(MODEL) takes an MGPLVM
%	model structure and breaks it into component parts for saving.
%	 Returns:
%	  COMP - the components of the MGPLVM model.
%	  NOISE - the noise component of the MGPLVM model.
%	  MGPLVMINFO - a structure containing the other information from the
%	   MGPLVM: what the active set is, what the inactive set is and what
%	   the site parameters are.
%	 Arguments:
%	  MODEL - the model that needs to be saved.
%	
%
%	See also
%	MGPLVMRECONSTRUCT, GPDECONSTRUCT


%	Copyright (c) 2009, 2013 Neil D. Lawrence


  comp = model.comp;

  removeCompFields = {'S', 'X', 'y', 'm', 'diagK', 'K_uu', 'invK_uu', 'logDetK_uu', ...
                  'alpha', 'K_uf', 'sqrtK_uu', 'K', 'sqrtK_uu', 'innerProducts', ...
                  'A', 'Ainv', 'logDetA', 'L', 'diagD', 'detDiff', 'Dinv', ...
                  'logDetD', 'V', 'Am', 'Lm', 'invLmV', 'scaledM', 'bet'};
  for i = 1:length(removeCompFields)
    for j = 1:length(comp)
      if isfield(comp{j}, removeCompFields{i})
        comp{j} = rmfield(comp{j}, removeCompFields{i});
      end
    end
  end

  
  if isfield(model, 'noise')
    noise = model.noise;
  else
    noise = [];
  end
  mgplvmInfo = model;
  removeFields = {'D', 'noise', 'comp', 'expectations'};
  
  for i = 1:length(removeFields)
    if isfield(mgplvmInfo, removeFields{i})
      mgplvmInfo = rmfield(mgplvmInfo, removeFields{i});
    end
  end
  X = model.X;
end

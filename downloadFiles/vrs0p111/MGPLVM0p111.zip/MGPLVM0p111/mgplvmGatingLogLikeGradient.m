function [gX] = mgplvmGatingLogLikeGradient(model)

% MGPLVMGATINGLOGLIKEGRADIENT Compute the gradients of gates of a MGPLVM model.
%
%	Description:
%
%	GX = MGPLVMGATINGLOGLIKEGRADIENT(MODEL) returns the gradients with
%	respect to X of the gating component of the likelihood.
%	 Returns:
%	  GX - the gradients of the gating terms with respect to X.
%	 Arguments:
%	  MODEL - the model for which the gradients are being computed.
%	
%
%	See also
%	MODELCREATE, MGPLVMOPTIONS


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmGatingLogLikeGradient.m CVS version 1.3
% 	mgplvmGatingLogLikeGradient.m SVN version 355
% 	last update 2008-02-04T17:59:47.000000Z

  
gX = zeros(model.N, model.q);
for m=1:model.M
  gX = gX + repmat(model.gating.centres(m,:),model.N,1).*(repmat(model.expectation.s(:,m),1,model.q) - repmat(model.pi(:,m),1,model.q));   
end



% MGPLVMTOOLBOXES Load in the relevant toolboxes for mgplvm.
%
%	Description:
%	% 	mgplvmToolboxes.m CVS version 1.2
% 	mgplvmToolboxes.m SVN version 2778
% 	last update 2013-03-13T10:17:28.523885Z
importLatest('netlab');
importLatest('GPmat');

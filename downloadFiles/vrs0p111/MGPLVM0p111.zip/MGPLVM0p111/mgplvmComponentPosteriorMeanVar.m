function [mu, varsigma, secondMoment] = mgplvmComponentPosteriorMeanVar(model, X)

% MGPLVMCOMPONENTPOSTERIORMEANVAR Mean and variance under each component of the mixture model.
%
%	Description:
%
%	[MU, VARSIGMA] = MGPLVMCOMPONENTPOSTERIORMEANVAR(MODEL, X) computes
%	the means and variances of each component of the mixture model.
%	 Returns:
%	  MU - the mean for each component (as a cell array).
%	  VARSIGMA - the variance for each component (as a cell array).
%	 Arguments:
%	  MODEL - the model for which the means and variances are to be
%	   computed.
%	  X - the inputs for which the means and variances are to be
%	   computed.
%	
%
%	See also
%	MGPLVMPOSTERIORMEANVAR, MGPLVMESTEP


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmComponentPosteriorMeanVar.m CVS version 1.2
% 	mgplvmComponentPosteriorMeanVar.m SVN version 355
% 	last update 2008-01-02T23:52:35.000000Z
  
% Work out component means and variances.
for m = 1:model.M
  X_active = model.X(find(model.activePoints(:, m)), :);
  Y_active = model.y(find(model.activePoints(:, m)), :);
  model.K{m} = kernCompute(model.comp{m}.kern, X_active);
  diagK = kernDiagCompute(model.comp{m}.kern, X);
  KX_star = kernCompute(model.comp{m}.kern, X_active, X);
  model.B{m} = diag(model.beta*model.expectation.s(find(model.activePoints(:, m)), m));
  model.Binv{m} = diag(1./diag(model.B{m}));  
  Kinvk = pdinv(model.K{m} + model.Binv{m})*KX_star;
  mu{m} = Kinvk'*Y_active;

  if nargout > 1
    varsigma{m} = diagK - sum(KX_star.*Kinvk, 1)';
    if nargout > 2
      secondMoment{m} = repmat(varsigma{m}, 1, model.d) ...
          + mu{m}.*mu{m};
    end
  end
end

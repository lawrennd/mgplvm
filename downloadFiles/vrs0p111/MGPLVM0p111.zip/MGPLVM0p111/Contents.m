% MGPLVM toolbox
% Version 0.111		13-Mar-2013
% Copyright (c) 2013, Neil D. Lawrence
% 
, Neil D. Lawrence
% MGPLVMGATINGLOGLIKEGRADIENTTEST Test gradients of gating.
% MGPLVMCOMPUTEINITASSIGNMENT Compute an inital assignment for the mixtures.
% MGPLVMCREATE Create a MGPLVM model.
% DEMVOWELS90MGPLVM1 Demonstrate mixtues of DPPCA on vowels90 data, with back-constraints
% MGPLVMOPTIONS Return default options for mixtures of GP-LVM.
% MGPLVMLOGLIKEGRADIENTS Compute gradients for the MGPLVM model.
% MGPLVMPLOTCLUSTERS plots the cluster labels associated with the latent space.
% MGPLVMGATINGLOGLIKEGRADIENT Compute the gradients of gates of a MGPLVM model.
% MGPLVMESTEP Run the variational E step for the MGPLVM model.
% MGPLVMLOGLIKELIHOOD Log likelihood of a mixtures of GP-LVM model.
% MGPLVMDYNAMICSRUN Runs auto regressive dynamics in a forward manner.
% MGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% MGPLVMEXTRACTPARAM Extract a parameter vector from a MGPLVM model.
% DEMBRENDANMGPLVM1 Model the face data with a 2-D RBF GPLVM.
% DEMOIL100MGPLVM1 Demonstrate mixtues of DPPCA on oil100 data, with back-constraints
% MGPLVMPRINTPLOTCLUSTERS plots the cluster labels associated with the latent space.
% MGPLVMUPDATES Update the S values and associated activepoints.
% MGPLVMGATINGPROBABILITIES Compute the gating probabilities for the
% MGPLVMLOADRESULT Load a previously saved result.
% MGPLVMWRITERESULT Write a MGPLVM result.
% MGPLVMDISPLAY Display an MGPLVM model.
% MGPLVMLATENTPRIORLOGLIKELIHOOD Compute likelihood of prior in latent space.
% MGPLVMCOMPUTES Compute the expectation of the indicator matrix.
% MGPLVMTEST Test the gradients of the MGPLVM model.
% MGPLVMGRADIENT Mixtures of GP-LVM gradient wrapper.
% DEMOILMGPLVM3 Demonstrate mixtues of RBF GPLVM on oil data, with back-constraints
% KERNCREATE Initialise a kernel structure.
% MGPLVMCOMPUTEPI Compute the expectations of the component priors.
% DEMSTICKMGPLVM1 Model the stick man using an linear kernel and dynamics.
% MGPLVMCOMPONENTPOSTERIORMEANVAR Mean and variance under each component of the mixture model.
% MGPLVMTOOLBOXES Load in the relevant toolboxes for mgplvm.
% MGPLVMLATENTPRIORLOGLIKEGRADIENTS Compute gradients of prior in latent space.
% TRANSLATEKERNCOMPUTE Compute the TRANSLATE kernel given the parameters and X.
% MGPLVMEXPANDPARAM Expand a parameter vector into a MGPLVM model.
% MGPLVMDECONSTRUCT break MGPLVM in pieces for saving.
% DEMSTICKMGPLVM2 Model the stick man using an RBF kernel and dynamics.
% MGPLVMOPTIMISE Optimise the mixtures of GP-LVM.
% MGPLVMEMOPTIMISE Optimise the mixture model using the EM algorithm.
% MGPLVMRECONSTRUCT Reconstruct an MGPLVM from component parts.
% DEMOILMGPLVM2 Demonstrate mixtues of DPPCA on oil data, with back-constraints
% DEMOILMGPLVM1 Demonstrate mixtues of DPPCA on oil data, with back-constraints
% MGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% MGPLVMOBJECTIVE Wrapper function for mixtures of GP-LVM objective.

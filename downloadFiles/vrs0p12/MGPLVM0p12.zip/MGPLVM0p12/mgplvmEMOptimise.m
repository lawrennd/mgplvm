function model = mgplvmEMOptimise(model, display, outerIters, eIters, mIters)

% MGPLVMEMOPTIMISE Optimise the mixture model using the EM algorithm.
%
%	Description:
%
%	MODEL = MGPLVMEMOPTIMISE(MODEL, DISPLAY, OUTERITERS, EITERS, MITERS)
%	optimises the given mixture of GP-LVM model using a KL corrected EM
%	algorithm.
%	 Returns:
%	  MODEL - the optimised model.
%	 Arguments:
%	  MODEL - the model to be optimised.
%	  DISPLAY - whether or not to display the results (default 1).
%	  OUTERITERS - maximum number of EM steps (default 40).
%	  EITERS - number of iterations in the E step (default 10).
%	  MITERS - number of iterations in the M step (default 100).
%	
%
%	See also
%	MGPLVMOPTIMISE, MGPLVMCREATE, MGPLVMESTEP


%	Copyright (c) 2007 % COPYRIGHT ; Neil D. Lawrence and Raquel Urtasun
% 	mgplvmEMOptimise.m CVS version 1.1
% 	mgplvmEMOptimise.m SVN version 355
% 	last update 2011-07-04T18:58:40.000000Z


if nargin < 5
  mIters = 100;
  if nargin < 4
    eIters = 10;
    if nargin < 3
      outerIters = 40;
      if nargin < 2
        display = 1;
      end
    end
  end
end

for outer = 1:outerIters
  disp(['Outer iteration ... ',num2str(outer)]);
  model = mgplvmEstep(model, display, eIters);  
  model = mgplvmOptimise(model, display, mIters); 
end

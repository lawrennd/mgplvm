function fileName = mgplvmWriteResult(model, dataSet, number)

% MGPLVMWRITERESULT Write a MGPLVM result.
%
%	Description:
%
%	FILENAME = MGPLVMWRITERESULT(MODEL, DATASET, NUMBER) writess an
%	MGPLVM result.
%	 Returns:
%	  FILENAME - the file name used to write.
%	 Arguments:
%	  MODEL - the model to write.
%	  DATASET - the name of the data set to write.
%	  NUMBER - the number of the MGPLVM run to write.
%	
%
%	See also
%	FGPLVMLOADRESULT


%	Copyright (c) 2009, 2011 Neil D. Lawrence
% 	mgplvmWriteResult.m SVN version 2779
% 	last update 2013-03-13T14:56:12.587887Z

dataSet(1) = upper(dataSet(1));
type = model.type;
type(1) = upper(type(1));
fileName = ['dem' dataSet type num2str(number)];

[comp, noise, mgplvmInfo, X] = mgplvmDeconstruct(model);

save(fileName, 'comp', 'noise', 'mgplvmInfo', 'X');
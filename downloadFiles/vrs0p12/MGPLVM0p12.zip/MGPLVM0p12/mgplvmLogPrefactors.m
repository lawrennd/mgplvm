function logc = mgplvmLogPrefactors(model)

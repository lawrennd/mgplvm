function [model, lbls] = mgplvmLoadResult(dataSet, number)

% MGPLVMLOADRESULT Load a previously saved result.
%
%	Description:
%
%	[MODEL, LBLS] = MGPLVMLOADRESULT(DATASET, NUMBER) loads a previously
%	saved FGPLVM result.
%	 Returns:
%	  MODEL - the saved model.
%	  LBLS - labels of the data set (for visualisation purposes).
%	 Arguments:
%	  DATASET - the name of the data set to load.
%	  NUMBER - the number of the FGPLVM run to load.
%	
%
%	See also
%	FGPLVMLOADRESULT


%	Copyright (c) 2003, 2004, 2005, 2006, 2008, 2013 Neil D. Lawrence
% 	mgplvmLoadResult.m SVN version 2779
% 	last update 2013-03-13T14:54:37.703885Z

[Y, lbls] = lvmLoadData(dataSet);

dataSet(1) = upper(dataSet(1));
load(['dem' dataSet 'Mgplvm' num2str(number)])
model = mgplvmReconstruct(comp, noise, mgplvmInfo, X, Y);
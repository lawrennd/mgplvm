function ll = mgplvmLogLikelihood(model)

% MGPLVMLOGLIKELIHOOD Log likelihood of a mixtures of GP-LVM model.
%
%	Description:
%
%	LL = MGPLVMLOGLIKELIHOOD(MODEL) computes the model log likelihood.
%	 Returns:
%	  LL - the log likelihood of the model.
%	 Arguments:
%	  MODEL - the model for which the log likelihood is required.
%	
%
%	See also
%	MGPLVMCREATE, MODELLOGLIKELIHOOD


%	Copyright (c) 2007, 2008 Raquel Urtasun and Neil D. Lawrence
% 	mgplvmLogLikelihood.m CVS version 1.3
% 	mgplvmLogLikelihood.m SVN version 355
% 	last update 2008-02-04T17:59:47.000000Z
  
ll = 0;
for m=1:model.M
  ll = ll + gpLogLikelihood(model.comp{m});
end

ll = ll + mgplvmLogPrefactors(model);
ll = ll + mgplvmLatentPriorLogLikelihood(model);

function model = mgplvmEstep(model, display, iters)

% MGPLVMESTEP Run the variational E step for the MGPLVM model.
%
%	Description:
%
%	MGPLVMESTEP(MODEL, DISPLAY, ITERS) computes the expectations
%	required in the E step of the mixtures of GP-LVM model. Strictly
%	speaking it isn't a pure E step as some of the parameters are also
%	maximised here.
%	 Arguments:
%	  MODEL - the model for which the E step is required.
%	  DISPLAY - the display level during optimisation (default 1).
%	  ITERS - the number of iterations to perform within the E-step
%	   (default 10).
%	
%
%	See also
%	MGPLVMOPTIMISE, MGPLVMEMOPTIMISE, MGPLVMCREATE


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmEstep.m CVS version 1.2
% 	mgplvmEstep.m SVN version 355
% 	last update 2008-02-06T12:05:05.000000Z

[model.expectation.f, model.expectation.varf] = mgplvmComponentPosteriorMeanVar(model, model.X);


if nargin < 3
  iters = 10;
  if nargin < 2
    display = 1;
  end
end

for iter = 1:iters
  if display
    fprintf('Estep iteration %d\n', iter)
  end
  
  % Update S.
  model = mgplvmUpdateS(model);
  if ~model.optimiseCentres & model.estepCentres
    for m=1:model.M
      if sum(model.expectation.s(:, m))<=model.minActive*model.activeThreshold
        % Throw unused centres back on random latent position.
        model.gating.centres(m, :) = model.X(ceil(rand(1)*model.N), :);
        
      else
        model.gating.centres(m, :) =  full(sum(repmat(model.expectation.s(:, ...
                                                          m), 1, ...
                                                      model.q).*model.X)/sum(model.expectation.s(:, m)));
      end
    end
  end
  
  % Force kernel updates.
  param = mgplvmExtractParam(model);
  model = mgplvmExpandParam(model, param);
  
  
  
  % Update expectations of F.
  [model.expectation.f, model.expectation.varf] = mgplvmComponentPosteriorMeanVar(model, model.X);
end

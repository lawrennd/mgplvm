function [gX, gcentres, gDynParam] = mgplvmLatentPriorLogLikeGradients(model, gX)

% MGPLVMLATENTPRIORLOGLIKEGRADIENTS Compute gradients of prior in latent space.
%
%	Description:
%
%	[GX, GCENTRES, GDYNPARAM] = MGPLVMLATENTPRIORLOGLIKEGRADIENTS(MODEL,
%	GX) computes the gradients with respect to the log likelihood of the
%	prior in the latent space.
%	 Returns:
%	  GX - Updated latent gradients with respect to X.
%	  GCENTRES - Latent gradients with respect to centres.
%	  GDYNPARAM - Latent gradients with respect to dynamics parameters.
%	 Arguments:
%	  MODEL - the model for which log likelihood is required.
%	  GX - Pre-existing latent gradients with respect to X.
%	
%
%	See also
%	MGPLVMLATENTPRIORLOGLIKELIHOOD, MGPLVMLOGLIKEGRADIENTS, MGPLVMCREATE


%	Copyright (c) 2007 Neil D. Lawrence and Raquel Urtasun
% 	mgplvmLatentPriorLogLikeGradients.m SVN version 355
% 	last update 2008-02-04T17:59:41.000000Z

 
if model.isGating 
  gX = gX + mgplvmGatingLogLikeGradient(model);
elseif ~model.compLabelConstr
  for m=1:model.M
    ind = find(model.activePoints(:, m));
    gX(ind, :) = gX(ind, :) ...
        - repmat(model.expectation.s(ind, m), 1, model.q) ...
        .*(model.X(ind, :) ...
           - repmat(model.gating.centres(m, :), length(ind), 1))/model.gating.scale;
  end
end

gDynParam = [];
gcentres = [];


if model.optimiseCentres
  gcentres = zeros(model.M,model.q);
  % compute the derivative of each center
  if model.isGating
    for m=1:model.M
      common_f = model.expectation.s(:,m)-model.pi(:,m);
      gcentres(m,:) = sum(model.X.*repmat(common_f,1,model.q))-model.gating.centres(m,:)*sum(common_f);  
    end      
    %gcentres = model.d*gcentres;
  elseif ~model.compLabelConstr
    for m = 1:model.M
      ind = find(model.activePoints(:, m));
      gcentres(m, :) = sum(repmat(model.expectation.s(ind, m), ...
                                  1, model.q).*(model.X(ind, :) - ...
                                                repmat(model.gating ...
                                                       .centres(m, :), ...
                                                       length(ind), 1)), ...
                           1)/model.gating.scale;
    end
  end
  gcentres = gcentres-model.gating.centres; % add the derivative of the normalization of the centres
end

% Check if Dynamics kernel is being used.
if isfield(model, 'dynamics') & ~isempty(model.dynamics)
  
  % Get the dynamics parameters
  gDynParam = modelLogLikeGradients(model.dynamics);
  
  % Include the dynamic's latent gradients.
  gX = gX + modelLatentGradients(model.dynamics);
  
elseif isfield(model, 'prior') &  ~isempty(model.prior)
  gX = gX + priorGradient(model.prior, model.X); 
end

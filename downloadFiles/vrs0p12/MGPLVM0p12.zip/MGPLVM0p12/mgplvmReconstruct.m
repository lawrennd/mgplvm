function model = mgplvmReconstruct(comp, noise, mgplvmInfo, X, Y)

% MGPLVMRECONSTRUCT Reconstruct an MGPLVM from component parts.
%
%	Description:
%
%	MODEL = MGPLVMRECONSTRUCT(COMP, NOISE, MGPLVMINFO, X, Y) takes
%	component parts of an MGPLVM model and reconstructs the MGPLVM
%	model. The component parts are normally retrieved from a saved file.
%	 Returns:
%	  MODEL - an MGPLVM model structure that combines the component
%	   parts.
%	 Arguments:
%	  COMP - a component structure for the MGPLVM.
%	  NOISE - a noise structure for the MGPLVM (currently ignored).
%	  MGPLVMINFO - the active set and the inactive set of the MGPLVM as
%	   well as the site parameters, stored in a structure.
%	  X - the input training data for the MGPLVM.
%	  Y - the output target training data for the MGPLVM.
%	
%
%	See also
%	MGPLVMDECONSTRUCT, MGPLVMCREATE, GPRECONSTRUCT


%	Copyright (c) 2009, 2013 Neil D. Lawrence
% 	mgplvmReconstruct.m SVN version 2779
% 	last update 2013-03-13T12:41:59.331935Z

  model = mgplvmInfo;
  model.y = Y;
  model.X = X;
  model.type = 'mgplvm';
  model.comp = comp;
  if ~isempty(noise)
    model.noise = noise;
  end
  
  params = mgplvmExtractParam(model);
  model = mgplvmExpandParam(model, params);

end
